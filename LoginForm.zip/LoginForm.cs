﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace CodeChum
{
    public partial class LoginForm : Form
    {
        private Dictionary<string, string> userCredentials;

        public LoginForm()
        {
            InitializeComponent();
            InitializeUserCredentials();
        }

        private void InitializeUserCredentials()
        {
            userCredentials = new Dictionary<string, string>
            {
                { "admin", "admin12345" },
                { "user1", "password123" },
                { "student1", "PF101@2024" }
            };
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            string username = usernameTextBox.Text;
            string password = passwordTextBox.Text;

            if (userCredentials.ContainsKey(username) && userCredentials[username] == password)
            {
                resultLabel.Text = "Login Successful";
            }
            else
            {
                resultLabel.Text = "Invalid username or password.";
            }
        }
    }
}